package com.example.recipe_app

object Constants {
    //const val API_KEY = "71f1502f6faf4eacb45b78e507889679" //my key
    //const val API_KEY = "1e2ee5b1d4964927aa5d26354c90c768"
    const val API_KEY = "9b31a6de51e34ce89699ac0e7ac03199"
}