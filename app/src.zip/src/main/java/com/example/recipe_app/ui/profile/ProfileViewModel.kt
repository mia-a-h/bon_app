package com.example.recipe_app.ui.profile

class ProfileViewModel {
}